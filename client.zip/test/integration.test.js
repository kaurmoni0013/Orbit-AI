import test from "node:test";
import assert from "node:assert/strict";
import mongoose from "mongoose";
import { MongoMemoryReplSet } from "mongodb-memory-server";
import app from "../app.js";
import openRouter from "../config/openRouter.js";
import { redisClient } from "../config/redis.js";
import User from "../model/userSchema.js";
import Chat from "../model/chatSchema.js";
import Message from "../model/messageSchema.js";
import { updateSummaryIfNeeded } from "../service/summaryService.js";
import { buildMessagesForAI } from "../utils/chatContext.js";

const MODEL = "openai/gpt-4o-mini";
const PASSWORD = "StrongPassword!";
const redisValues = new Map();
const redisExpiries = new Map();
let providerMode = "success";
let server;
let baseUrl;
let mongo;
let originalRedisMethods;
let originalSend;
let providerCalls = 0;

const sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

const getCookie = (response) => {
    const cookie = response.headers.get("set-cookie");
    assert.ok(cookie, "expected an authentication cookie");
    return cookie.split(";")[0];
};

const request = (path, options = {}, cookie) => fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
        ...(options.body ? { "content-type": "application/json" } : {}),
        ...(cookie ? { cookie } : {}),
        ...(options.headers || {}),
    },
});

const jsonRequest = (path, body, cookie, method = "POST") => request(path, {
    method,
    body: JSON.stringify(body),
}, cookie);

const signup = async (suffix) => {
    const response = await jsonRequest("/user/signup", {
        name: `Test ${suffix}`,
        age: 25,
        email: `${suffix}@example.com`,
        password: PASSWORD,
    });
    assert.equal(response.status, 201);
    return { cookie: getCookie(response), email: `${suffix}@example.com` };
};

const streamChunks = (chunks, usage = { promptTokens: 4, completionTokens: 6 }) => ({
    async *[Symbol.asyncIterator]() {
        for (const content of chunks) {
            yield { choices: [{ delta: { content } }] };
        }
        yield { usage };
    },
});

const installRedisDouble = () => {
    const methods = ["get", "incr", "incrBy", "expire", "ttl", "set"];
    originalRedisMethods = Object.fromEntries(methods.map((method) => [method, redisClient[method]]));
    redisClient.get = async (key) => redisValues.get(key) ?? null;
    redisClient.incr = async (key) => {
        const value = Number(redisValues.get(key) || 0) + 1;
        redisValues.set(key, String(value));
        return value;
    };
    redisClient.incrBy = async (key, amount) => {
        const value = Number(redisValues.get(key) || 0) + amount;
        redisValues.set(key, String(value));
        return value;
    };
    redisClient.expire = async (key, seconds) => {
        redisExpiries.set(key, seconds);
        return 1;
    };
    redisClient.ttl = async (key) => redisExpiries.has(key) ? redisExpiries.get(key) : -1;
    redisClient.set = async (key, value, options = {}) => {
        redisValues.set(key, value);
        if (options.EX) redisExpiries.set(key, options.EX);
        return "OK";
    };
};

const installProviderDouble = () => {
    originalSend = openRouter.chat.send;
    openRouter.chat.send = async (payload) => {
        providerCalls += 1;
        if (providerMode === "failure") {
            throw new Error("provider unavailable");
        }
        if (providerMode === "stream-failure") {
            return {
                async *[Symbol.asyncIterator]() {
                    yield { choices: [{ delta: { content: "partial" } }] };
                    throw new Error("stream interrupted");
                },
            };
        }
        if (payload.chatRequest.stream) {
            return streamChunks(["Hello", " from Orbit"]);
        }
        return {
            choices: [{ message: { content: "Hello from Orbit" } }],
            usage: { promptTokens: 4, completionTokens: 6 },
        };
    };
};

test.before(async () => {
    mongo = await MongoMemoryReplSet.create({ replSet: { count: 1 } });
    await mongoose.connect(mongo.getUri());
    installRedisDouble();
    installProviderDouble();
    server = app.listen(0);
    baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
    openRouter.chat.send = originalSend;
    for (const [method, implementation] of Object.entries(originalRedisMethods)) {
        redisClient[method] = implementation;
    }
    await mongoose.disconnect();
    await mongo.stop();
    await new Promise((resolve) => server.close(resolve));
});

test.beforeEach(async () => {
    providerMode = "success";
    providerCalls = 0;
    redisValues.clear();
    redisExpiries.clear();
    await User.deleteMany({});
    await Chat.deleteMany({});
    await Message.deleteMany({});
});

test("signup, login, and authenticated profile use the JWT cookie", async () => {
    const created = await signup("cookie-user");
    const profile = await request("/user/profile", {}, created.cookie);
    assert.equal(profile.status, 200);
    assert.equal((await profile.json()).email, created.email);

    const login = await jsonRequest("/user/login", {
        email: created.email,
        password: PASSWORD,
    });
    assert.equal(login.status, 200);
    const loginProfile = await request("/user/profile", {}, getCookie(login));
    assert.equal(loginProfile.status, 200);
});

test("protected routes reject requests without authentication", async () => {
    const response = await request("/chat/getRecentChat");
    assert.equal(response.status, 401);
    assert.deepEqual(await response.json(), { message: "You need to login first" });
});

test("users cannot access another user's chat", async () => {
    const owner = await signup("owner");
    const other = await signup("other");
    const created = await jsonRequest("/chat/createChat", { model: MODEL }, owner.cookie);
    const { chatId } = await created.json();

    const read = await request(`/chat/${chatId}`, {}, other.cookie);
    const send = await jsonRequest(`/msg/${chatId}`, { content: "private" }, other.cookie);
    const remove = await request(`/chat/${chatId}`, { method: "DELETE" }, other.cookie);

    assert.equal(read.status, 404);
    assert.equal(send.status, 404);
    assert.equal(remove.status, 403);
});

test("users cannot delete another user's account data", async () => {
    const owner = await signup("account-owner");
    const other = await signup("account-other");
    await jsonRequest("/msg", {
        model: MODEL,
        content: "Keep this data",
    }, owner.cookie);

    const response = await request("/user/delete", { method: "DELETE" }, other.cookie);

    assert.equal(response.status, 200);
    assert.equal(await User.countDocuments({ email: owner.email }), 1);
    assert.equal(await Chat.countDocuments({}), 1);
    assert.equal(await Message.countDocuments({}), 2);
});

test("chat deletion rolls back messages when the chat delete fails", async () => {
    const user = await signup("chat-rollback");
    const created = await jsonRequest("/msg", {
        model: MODEL,
        content: "Keep this chat",
    }, user.cookie);
    const { chatId } = await created.json();
    const originalDeleteOne = Chat.deleteOne;
    Chat.deleteOne = async () => {
        throw new Error("chat delete failed");
    };

    try {
        const response = await request(`/chat/${chatId}`, { method: "DELETE" }, user.cookie);
        assert.equal(response.status, 500);
    } finally {
        Chat.deleteOne = originalDeleteOne;
    }

    assert.equal(await Chat.countDocuments({ _id: chatId }), 1);
    assert.equal(await Message.countDocuments({ chatId }), 2);
});

test("account deletion rolls back chats and messages when user delete fails", async () => {
    const user = await signup("account-rollback");
    await jsonRequest("/msg", {
        model: MODEL,
        content: "Keep account data",
    }, user.cookie);
    const originalDeleteOne = User.deleteOne;
    User.deleteOne = async () => {
        throw new Error("user delete failed");
    };

    try {
        const response = await request("/user/delete", { method: "DELETE" }, user.cookie);
        assert.equal(response.status, 500);
    } finally {
        User.deleteOne = originalDeleteOne;
    }

    const savedUser = await User.findOne({ email: user.email });
    assert.ok(savedUser);
    assert.equal(await Chat.countDocuments({ userId: savedUser._id }), 1);
    assert.equal(await Message.countDocuments({ userId: savedUser._id }), 2);
});

test("message creation persists the user/assistant pair and usage", async () => {
    const user = await signup("message-user");
    const response = await jsonRequest("/msg", {
        model: MODEL,
        content: "Explain testing",
    }, user.cookie);
    const body = await response.json();

    assert.equal(response.status, 201);
    assert.equal(body.reply, "Hello from Orbit");
    assert.equal(body.usage.totalTokens, 10);
    assert.equal(body.userMessage.role, "user");
    assert.equal(body.assistantMessage.role, "assistant");
    assert.equal(await Message.countDocuments({ chatId: body.chatId }), 2);

    const chat = await Chat.findById(body.chatId);
    const savedUser = await User.findOne({ email: user.email });
    assert.equal(chat.messageCount, 2);
    assert.equal(chat.usage.totalTokens, 10);
    assert.equal(savedUser.usage.totalTokenUsed, 10);
});

test("provider failure cleans up a newly created chat and messages", async () => {
    const user = await signup("failed-message");
    providerMode = "failure";
    const response = await jsonRequest("/msg", {
        model: MODEL,
        content: "This should fail",
    }, user.cookie);

    assert.equal(response.status, 500);
    assert.equal(await Chat.countDocuments({}), 0);
    assert.equal(await Message.countDocuments({}), 0);
});

test("successful streaming persists exactly one complete assistant response", async () => {
    const user = await signup("stream-user");
    const response = await jsonRequest("/msg/stream", {
        model: MODEL,
        content: "Stream this",
    }, user.cookie);
    const body = await response.text();

    assert.equal(response.status, 200);
    assert.match(body, /event: token/);
    assert.match(body, /Hello/);
    assert.match(body, /event: done/);
    const messages = await Message.find({}).sort({ createdAt: 1 });
    assert.equal(messages.length, 2);
    assert.equal(messages[0].role, "user");
    assert.equal(messages[1].role, "assistant");
    assert.equal(messages[1].content, "Hello from Orbit");
});

test("streaming failure does not persist partial or duplicate messages", async () => {
    const user = await signup("failed-stream");
    providerMode = "stream-failure";
    const response = await jsonRequest("/msg/stream", {
        model: MODEL,
        content: "Disconnect this",
    }, user.cookie);
    const body = await response.text();

    assert.equal(response.status, 200);
    assert.match(body, /event: error/);
    assert.equal(await Chat.countDocuments({}), 0);
    assert.equal(await Message.countDocuments({}), 0);
});

test("token and request limits reject work before the provider is called", async () => {
    const user = await signup("limited-user");
    const databaseUser = await User.findOne({ email: user.email });
    const tokenKey = `token-usage:${databaseUser._id}`;
    redisValues.set(tokenKey, "10000");
    const tokenResponse = await jsonRequest("/msg", {
        model: MODEL,
        content: "over quota",
    }, user.cookie);
    assert.equal(tokenResponse.status, 429);
    assert.equal(providerCalls, 0);

    redisValues.delete(tokenKey);
    redisValues.set(`rate-limit:user:${databaseUser._id}`, "20");
    const rateResponse = await request("/chat/getRecentChat", {}, user.cookie);
    assert.equal(rateResponse.status, 429);
    assert.equal(providerCalls, 0);
});

test("summary generation updates the chat and context stays within its configured limit", async () => {
    const user = await signup("summary-user");
    const chat = await Chat.create({
        userId: (await User.findOne({ email: user.email }))._id,
        model: MODEL,
        messageCount: 20,
    });
    await Message.insertMany(Array.from({ length: 20 }, (_, index) => ({
        userId: chat.userId,
        chatId: chat._id,
        role: index % 2 ? "assistant" : "user",
        content: `message-${index}`,
    })));

    await updateSummaryIfNeeded(chat._id);
    const summarized = await Chat.findById(chat._id);
    assert.equal(summarized.summarizedTillMessageNumber, 20);
    assert.equal(summarized.summary, "Hello from Orbit");

    const context = buildMessagesForAI({
        chat: { summary: "", summarizedTillMessageNumber: 0 },
        oldMessages: [{ role: "user", content: "x".repeat(30000) }],
        currentMessage: "latest",
    });
    assert.equal(context.at(-1).content, "latest");
    assert.equal(context.some((message) => message.content.length === 30000), false);
});

test("chat and account deletion remove related messages and chats", async () => {
    const user = await signup("deletion-user");
    const created = await jsonRequest("/msg", {
        model: MODEL,
        content: "Delete me",
    }, user.cookie);
    const { chatId } = await created.json();

    const deleteChat = await request(`/chat/${chatId}`, { method: "DELETE" }, user.cookie);
    assert.equal(deleteChat.status, 200);
    assert.equal(await Chat.countDocuments({}), 0);
    assert.equal(await Message.countDocuments({}), 0);

    await jsonRequest("/msg", { model: MODEL, content: "Delete account data" }, user.cookie);
    const deleteAccount = await request("/user/delete", { method: "DELETE" }, user.cookie);
    assert.equal(deleteAccount.status, 200);
    assert.equal(await User.countDocuments({}), 0);
    assert.equal(await Chat.countDocuments({}), 0);
    assert.equal(await Message.countDocuments({}), 0);
});
